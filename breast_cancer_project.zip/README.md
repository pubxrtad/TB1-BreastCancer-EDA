# Predicción de Cáncer de Mama - Proyecto TB1

Dataset guardado en: data/breast_cancer_wisconsin.csv
Notebook: notebooks/EDA_Breast_Cancer.ipynb
Report: reports/Nombre_TB1_ComprensionDatos.pdf

Roles ejemplo:
- Project Lead: Nombre
- Data Engineer: Nombre
- Data Analyst: Nombre
- Data Scientist: Nombre
